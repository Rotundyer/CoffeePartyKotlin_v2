package com.coffee.coffee_party_kotlin_v2.menu

import androidx.lifecycle.ViewModel

class MenuViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}